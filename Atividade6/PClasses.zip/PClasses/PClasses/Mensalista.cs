﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
    internal class Mensalista: Empregado
    {
        public double SalarioMensal { get; set; }

        public Mensalista() { }
        public Mensalista(int mat, string nomeEmpreg, DateTime dataEntrada, double salario): base(mat, nomeEmpreg, dataEntrada) {
            SalarioMensal = salario;
        }

        public static String Empresa = "Toyota";
        public const String Filial = "Filial Sorocaba";
        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
        
    }
}
