﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtPeso.Text, out peso) || peso <= 0)
            {
                MessageBox.Show("O peso não pode ser menor ou igual a 0");
                txtPeso.Focus();
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("A altura não pode ser menor ou igual a 0");
                txtAltura.Focus();
            }
        }

        private void lblCalcular_Click(object sender, EventArgs e)
        {
            double localIMC = peso / Math.Pow(altura, 2);
            localIMC = Math.Round(localIMC,1);
            if(localIMC >= 40)
            {
                MessageBox.Show("IMC correspondente a Obesidade Grave");
            } else if (localIMC >= 30)
            {
                MessageBox.Show("IMC correspondente a Obesidade");
            }
            else if(localIMC >= 25)
            {
                MessageBox.Show("IMC correspondente a Sobrepeso");
            }
            else if(localIMC >= 18.5)
            {
                MessageBox.Show("IMC correspondente a Normal");
            }
            else
            {
                MessageBox.Show("IMC correspondente a Magreza");
            }
        }

        private void lblLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtIMC.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
